// inits.hpp

// Funções de inicialização programa

#include "inits.cpp"

void initBallParameters();
void initAreaParameters();
void initBlueColorParameters();
void initYellowColorParameters();
void initParameters();
