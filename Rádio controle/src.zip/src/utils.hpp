// utils.hpp

// Funções de utilidade geral

#include "utils.cpp"

vector<string> split(string str, string sep);